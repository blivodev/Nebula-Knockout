# Changelog

> Get access to beta/dev versions exclusively on the [Discord server](/docs/update-guide).

## 0.3.3

- Add optional Streamable HTTP transport to the Python MCP adapter
- Update MCP SDKs and maintain compatibility with older MCP clients
- Fix editor shutdown crashes and headless import shutdown
- Fix runtime debugger capture lifecycle
- Fix runtime configuration memory leak

## 0.3.2

- Auto-enable runtime plugin
- Improve performance of runtime tools
- Update `get_open_scripts` to only return script paths
- Improve `get_scene_tree` tool
- Add running scene inspection for `get_scene_tree` tool
- Add running scene inspection for `get_node_properties` tool
- Add `search_nodes` tool
- Add `get_node_properties` tool

## 0.3.1

- Improve `execute_editor_script` with static types
- Improve `get_godot_errors` and add .NET build errors/output
- Added support for macOS 10.15+

## 0.3.0

- Update `move_node` to be able to move node to specific index
- Updates for `get_godot_errors` and `clear_output_logs` for Godot 4.6
- Added support for windows x64 double precision build

## 0.2.9

- Resolve windows defender issues

## 0.2.8

- Auto check for updates on start
- Improved `update_property` tool for string literals
- Fixed errors/crash when save scene is called concurrently
- Updated `get_godot_errors` to limit max lines returned for errors/session errors/etc
- `simulate_input` tool now presses the actual key rather than just the action
- Added disabling tools in config file
- New implementation for `get_running_scene_screenshot`

## 0.2.7

- Fix for Antigravity IDE on Windows ([Antigravity Windows Fix](/docs/installation#antigravity-windows-fix))
- Fixed `get_godot_errors` to work when Editor has different language
- Added windows arm64 support
- Added configuration file to update plugin configuration
- Now AI can simulate inputs in your game!
- Added tools `get_input_map` and `simulate_input`
- Don't load plugin when exporting project from Godot cli

## 0.2.6

- New implementation for `get_running_scene_screenshot` which supports more MCP clients

## 0.2.5

- Added support for Linux arm64
- Added `webp` image format for getting editor/running scene screenshots
- Fixed `get_running_scene_screenshot` freezing editor on some Windows devices

## 0.2.4

- Updated to latest MCP specification version 2025-06-18
- Added support for Godot 4.5
- Added `duplicate_node` tool to duplicate a node in a scene
- Added `move_node` tool to move a node to a different parent

## 0.2.3

- Added `uid_to_project_path` tool to convert uid:// to res://
- Added `project_path_to_uid` tool to convert res:// to uid://

## 0.2.2

- Added `get_running_scene_screenshot` tool that lets AI visually see your running game
- Added `set_anchor_values` tool to set individual anchor side values
- Added `set_anchor_preset` tool to set anchors using presets
- Added `stop_running_scene` tool that stops the running scene

## 0.2.1

- Fixed issue caused by newer dependency versions by pinning all dependencies to exact versions.
- Added `get_editor_screenshot` that lets AI visually see the entire Godot editor

## 0.2.0

- Improved GDAI MCP error logging
- Added `clear_output_logs` tool to clear output logs in the editor.
- Fixed `edit_file` tool in some cases would not be able to edit end of file correctly.
- Both `edit_file` and `view_script` tools also open the script in the editor.
- Updated `play_scene` tool description to inform the user to test the game and confirm its as expected before continuing.
- Added `view_script` tool for viewing GDScript files and useful to check for errors in script.
- Added `gdai-mcp-default-prompt` a custom MCP prompt for with Godot Best practices and GDAI MCP best practices.


## 0.1.0

- Initial early access version
